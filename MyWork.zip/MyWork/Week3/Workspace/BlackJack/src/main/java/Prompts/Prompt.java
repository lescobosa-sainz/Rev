package Prompts;

public interface Prompt {
	Prompt run();

}
