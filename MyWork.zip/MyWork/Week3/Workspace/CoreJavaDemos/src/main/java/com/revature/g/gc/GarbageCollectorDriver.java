package com.revature.g.gc;

public class GarbageCollectorDriver {

	public static void main(String[] args) {
		
		
		while(true) {
			
		}

	}

}
