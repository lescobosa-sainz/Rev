package com.revature.d.objects;

public class Animals {
	private String name;
	private boolean isAlive;

	public Animals() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Animals(String name, boolean isAlive) {
		super();
		this.name = name;
		this.isAlive = isAlive;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animals other = (Animals) obj;
		if (isAlive != other.isAlive)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Animals [name=" + name + ", isAlive=" + isAlive + "]";
	}

}
