package com.revature.h.Fibonacci;

public interface Screen {
	Screen run();

}
