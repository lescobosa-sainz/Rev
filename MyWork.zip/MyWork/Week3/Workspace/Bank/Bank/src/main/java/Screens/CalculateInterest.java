package Screens;

public class CalculateInterest implements Screen {

	@Override
	public Screen run() {
		
		System.out.println();
		
		
		return new HomeScreen();
	}

	
	
}
