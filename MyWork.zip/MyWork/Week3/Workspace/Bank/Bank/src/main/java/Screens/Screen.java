package Screens;

public interface Screen {
	Screen run();

}
