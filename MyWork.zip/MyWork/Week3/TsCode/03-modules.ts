import s, {Shirt, s2} from './02-classes';
import * as Shirts from "./02-classes";

console.log(s);
console.log(s2);
console.log(new Shirt());

console.log(Shirt.s2);