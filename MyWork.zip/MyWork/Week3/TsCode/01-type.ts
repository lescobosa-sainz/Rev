let a:number = 5;

console.log(a);

function add(one: number, two:number ):number{
    return one + two;
}

console.log(add(5,25));

let obj = {
    name: 'luis'
}
