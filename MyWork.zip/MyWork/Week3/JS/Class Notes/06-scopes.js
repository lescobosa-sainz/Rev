let a = 5;
var b = 10;