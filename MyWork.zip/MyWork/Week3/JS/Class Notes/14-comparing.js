function compare(one,two){
    console.log(`one = ${one} and is type: ${typeof(one)}
    two = ${two} and is type: ${typeof(two)}
    one == two returns: ${one==two}
    one===two returns: ${one===two}
    `);

}
compare(0,'0');
compare(1,'1');