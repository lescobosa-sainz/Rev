let laptop = {
    price : 500,
    brand : 'hp',
    batteryLife : 4,
    processor : {
    brand : "intel",
    cores : 4,
    model : "i7 7700u"
    }
}

console.log(laptop);