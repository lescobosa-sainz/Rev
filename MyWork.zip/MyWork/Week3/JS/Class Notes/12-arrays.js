let arr =[
    {
        name : 'rice',
        texture : 'grainy'
    },
    5,
    'hello',
    [3,2,8],
    true
];

console.log(arr);
console.log(arr[1]);
console.log(arr[3][0]);
console.log(arr[0].name);