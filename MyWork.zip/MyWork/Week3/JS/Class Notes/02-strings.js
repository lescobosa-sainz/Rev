let a = "hello";
let b = 'world';

let c = `the back tic allows us to create template  literals they allow for multiple 
ListeningStateChangedEvent. they also allow sting interpolation which allows us to inject

a = ${a}
b = ${b}
5 + 10 = ${5 + 10}
`;

console.log(c);
