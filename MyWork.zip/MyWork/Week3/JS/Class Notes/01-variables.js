let a = 5;

a = "hello";

const c = 10;

var v = 'dont use var';


console.log("a = " + a );
console.log("c = " + c );
console.log("v = " + v );