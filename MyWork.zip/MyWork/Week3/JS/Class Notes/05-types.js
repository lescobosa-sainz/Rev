function typeCheck(val){
    console.log(`the value ${val} is of type: ${typeof(val)}`);
}

typeCheck(5);
typeCheck(1.2);
typeCheck(true);
typeCheck(typeCheck);