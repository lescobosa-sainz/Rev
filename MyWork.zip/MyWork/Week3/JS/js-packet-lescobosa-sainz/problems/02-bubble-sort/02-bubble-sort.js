/* 2. Bubble Sort
Define function: bubbleSort(numArray)
Use the bubble sort algorithm to sort the array.
Return the sorted array. */
function bubbleSort(numArray) {


    numArray1 = numArray.slice();
  
    do {
        var swapped = false;

        for (let i = 0; i < numArray1.length -1; i++) {

            if (numArray1[i] > numArray1[i + 1]) {
                let tp = numArray1[i];
                numArray1[i] = numArray1[i + 1];
                numArray1[i + 1] = tp;
                swapped = true;
            }
            

        }
    }
    while (swapped === true);
    return console.log(numArray,numArray1);
}



bubbleSort([2, 4, 54, 6, 31, 25, 1, 10, 7, 8]);