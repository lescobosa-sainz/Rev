/* 1. Fibonacci
Define function: fib(n) 
Return the nth number in the fibonacci sequence. */


function fib(n) {
    let sequence = [0, 1];

    let result = 0;

    for (let i = 1; i < n-1; i++) {
        result = sequence[i-1] + sequence[i];
        sequence.push(result);
    }

    console.log(sequence);
    return console.log(sequence[n-1]);
}

fib(12);


