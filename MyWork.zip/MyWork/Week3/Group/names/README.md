| First Name    | Last Name     | GitHub Name   | email                        |
| ---------     | ----------    | -----------   | ----------                   |
| Blake         | Kruppa        | btkruppa      | blake.kruppa@revature.com    |
| Jordan        | Landberg      | jordanlandberg| jordanlandberg@gmail.com     |
| Phong         | Tran          | ptt5039       | pt.tran00@gmail.com          |   
| Thas		    | Eagans		| TREagans	    | thas.eagans@gmail.com        |
| Bre           | Dunn          | bredunnx      | bredunnx@gmail.com           |
| Sharell       | Gilchrist     | SharellG7     | sharellgilchrist@hotmail.com |
| Chris         | Prosser       | cbprosser     | chrisbprosser@gmail.com      |
| Elizabeth     | Grauvogel     | elizg         | elizabethgrauvogel@gmail.com |
| Brett         | Davis         | BrettDavis1   | 2014BrettDavis@gmail.com     |
| Christopher   | Levette       | chrstphlvt    | chrstphlvt@gmail.com         |
| Joseph        | Boakye        | jkb5j         | jkb5j@mtmail.mtsu.edu        |
| Nicholas      | Bray          | bray9468      | nbray101@gmail.com           |
| Abdulah       | Aqrabawi      | 3agrabawi     | abood.aqrab@hotmail.com      |
| Luis          | Escobosa-Sainz|lescobosa-sainz| lescobosa-sainz@hotmail.com  |
| Brenton       | Foster - Byrd | BrentonFB     | fosterbyrdbrenton@gmail.com  |
| Edward        | McIntire      | BigEFoot      | e.mcintire.64@gmail.com      |
| Bruce         | Houedenou     | brucehouedenou| brucehouedenou@gmail.com     |
| Matt          | Arsenault     | MJArsen       | MattJArsenault82@gmail.com   |
| Carri         | Martin        | carrichk      | carrichka@yahoo.com          |
| yosuke        | kibe          | this-is-yosuke| yosuke.kibe@gmail.com        |
| Sandhya       | Bagalkotkar   | sandhyabagal  | sandhyabagal@gmail.com       |